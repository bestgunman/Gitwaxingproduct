from django.apps import AppConfig


class AccountappConfig(AppConfig):
    name = 'accountapp'
