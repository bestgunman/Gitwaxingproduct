from django.apps import AppConfig


class ReviewappConfig(AppConfig):
    name = 'reviewapp'
