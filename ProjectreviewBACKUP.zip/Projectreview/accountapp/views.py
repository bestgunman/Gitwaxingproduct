from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User

# Create your views here.
def login_view(request):
	context = {}
	if request.method=="POST":
		userid = request.POST['username']
		userpw = request.POST['password']
		user = authenticate(username = userid, password = userpw)
		if user is not None:
			login(request, user)
			return redirect('/review')
		else:
			context = {'check': '아이디나 패스워드가 틀렸습니다'}
	else:
		context = {'check': '아이디와 패스워드를 입력하세요'}
	return render(request, 'loginpage.html', context)
	
def logout_view(request):
	logout(request)
	return redirect('/accountapp/loginview/')

def signup_view(request):
	if request.method=="POST":
		userid = request.POST['create_id']
		useremail = request.POST['create_email']
		userpw1 = request.POST['password1']
		userpw2 = request.POST['password2']
		if User.objects.filter(username=userid).exists():
			context = {'error':'이미 존재하는 아이디 입니다'}
			return render(request, 'signuppage.html', context)
		if User.objects.filter(email=useremail).exists():
			context = {'error':'이미 존재하는 이메일 입니다'}
			return render(request, 'signuppage.html', context)
		if userpw1 != userpw2:
			context = {'error':'패스워드가 다릅니다'}
			return render(request, 'signuppage.html',context)

		user = User.objects.create_user(userid, useremail, userpw1)
		user.save()
		user = authenticate(username = userid, password = userpw1)
		login(request, user)
		return redirect('/review')
	else:
		return render(request, 'signuppage.html')
	